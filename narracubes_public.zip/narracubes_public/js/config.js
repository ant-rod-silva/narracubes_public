// Define the image directories for dice and numeric options
var imageDirectories = {
	scientist: "img/scientist/",
	cosmos: "img/cosmos/",
	custom: "img/custom/",
	mixed: "img/mixed/"	
};
// Define the dice face images
var scientistImages = [
	"none.jpg",
	"scientist_dice_1.jpg",
	"scientist_dice_2.jpg",
	"scientist_dice_3.jpg",
	"scientist_dice_4.jpg",
	"scientist_dice_5.jpg",
	"scientist_dice_6.jpg",
	"scientist_dice_7.jpg"
];
var cosmosImages = [
	"none.jpg",
	"cosmos_dice_1.jpg",
	"cosmos_dice_2.jpg",
	"cosmos_dice_3.jpg",
	"cosmos_dice_4.jpg",
	"cosmos_dice_5.jpg",
	"cosmos_dice_6.jpg"
];
var customImages = [
	"none.jpg",
	"custom_dice_1.jpg",
	"custom_dice_2.jpg",
	"custom_dice_3.jpg",
	"custom_dice_4.jpg",
	"custom_dice_5.jpg",
	"custom_dice_6.jpg",
	"custom_dice_7.jpg",
	"custom_dice_8.jpg",
	"custom_dice_9.jpg",
	"custom_dice_10.jpg",
	"custom_dice_11.jpg"	
];
var mixedImages = [
	"none.jpg",
	"custom_dice_1.jpg",
	"custom_dice_2.jpg",
	"custom_dice_3.jpg",
	"custom_dice_4.jpg",
	"custom_dice_5.jpg",
	"custom_dice_6.jpg",
	"custom_dice_7.jpg",
	"custom_dice_8.jpg",
	"custom_dice_9.jpg",
	"custom_dice_10.jpg",
	"cosmos_dice_1.jpg",
	"cosmos_dice_2.jpg",
	"cosmos_dice_3.jpg",
	"cosmos_dice_4.jpg",
	"cosmos_dice_5.jpg",
	"cosmos_dice_6.jpg",
	"scientist_dice_1.jpg",
	"scientist_dice_2.jpg",
	"scientist_dice_3.jpg",
	"scientist_dice_4.jpg",
	"scientist_dice_5.jpg",
	"scientist_dice_6.jpg",
	"scientist_dice_7.jpg"
];

// email parameters
const email_from = "frommail@gmail.com"
const email_to = "tomail@gmail.com"
const emailjs_public_key = "PUBL1CK3Y"
const emailjs_service = "service_k3y"
const emailjs_template = "template_k3y"